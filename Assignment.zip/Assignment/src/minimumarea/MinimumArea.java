package minimumarea;
import java.util.Arrays;
import java.util.Scanner;

public class MinimumArea {

	public int minArea(int x[], int y[], int minimumPoints)throws NullPointerException, ArrayIndexOutOfBoundsException
	{
		Arrays.sort(x);
		Arrays.sort(y);
		int xMin,xMax,yMin,yMax;
		xMin=x[0];
		xMax=x[x.length-1];
		yMin=y[0];
		yMax=y[y.length-1];
		int xSide=xMax-xMin+2;
		int ySide=yMax-yMin+2;	
		int squareSize=(ySide > xSide)?ySide:xSide;
		return squareSize*squareSize;
	}
	public static void main(String[] args) {
		
		try
		{
			MinimumArea obj= new MinimumArea();
			int xSize, ySize;
			Scanner in= new Scanner(System.in);
			xSize=in.nextInt();
			int x[]= new  int[xSize];
			for(int i=0;i<xSize;i++)
				x[i]=in.nextInt();			
			ySize=in.nextInt();
			int y[]= new  int[ySize];
			for(int i=0;i<ySize;i++)
				y[i]=in.nextInt();		
			int minimumPoints=in.nextInt();
			System.out.println(obj.minArea(x, y, minimumPoints));
		}
		catch(ArrayIndexOutOfBoundsException exception)
		{
			System.out.println("Exception occured : ArrayIndexOutOfBoundsException ");
		}
		catch(NullPointerException exception)
		{
			System.out.println("Exception occured : NullPointerException ");
		}
	}

}
