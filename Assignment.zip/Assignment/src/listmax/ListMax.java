package listmax;
import java.util.Scanner;

public class ListMax {

	public int listMax(int size, int operations[][])
	{
		int rowSize, columnSize;
		rowSize=operations.length;
		columnSize=operations[0].length;
		int basicList[] = new int[size];
		int maxValue=0;
		for(int i=0;i<rowSize;i++)
			for(int j=operations[i][0]-1;j<=operations[i][1]-1;j++)
			{
				basicList[j]=basicList[j]+operations[i][columnSize-1];
				if(maxValue < basicList[j])
					maxValue=basicList[j];
			}
		
		return maxValue;
		
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int size = in.nextInt();
		
		int numberOfOperations=in.nextInt();
		int numberOfElements=in.nextInt();
		int operations[][]= new int[numberOfOperations][numberOfElements];
		for(int i=0;i<numberOfOperations;i++)
			for(int j=0;j<numberOfElements;j++)
				operations[i][j]=in.nextInt();		
		ListMax obj=new ListMax();
		System.out.println(obj.listMax(size,operations));
	}

}
