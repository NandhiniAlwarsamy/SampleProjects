package shortestsubstring;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ShortestSubstring {

	public int shortestSubstring(String inputString)
	{
		Set<Character> charSet = new HashSet<Character>();

		for (char c : inputString.toCharArray()) {
		  charSet.add(c);
		}
		
		return charSet.size();
	}

	public static void main(String[] args) {

		Scanner in= new Scanner(System.in);
		String inputString= new String();
		inputString = in.nextLine();
		ShortestSubstring substringObj =  new ShortestSubstring();
		
		if(inputString.matches(".*[A-Z0-9].*"))
			System.out.println("The String must contain only lower case characters ");
		else
		{
			System.out.println(substringObj.shortestSubstring(inputString));
		}
		
	}

}
